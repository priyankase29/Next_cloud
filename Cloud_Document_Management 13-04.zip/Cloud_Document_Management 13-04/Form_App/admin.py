from django.contrib import admin
from Form_App.models import profile
from.models import *

# Register your models here.
admin.site.register(profile)
